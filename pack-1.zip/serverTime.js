var http = require('http');
var fs = require('fs');
var url = require('url');


// 创建服务器
http.createServer(function (request, response) {
   let time = new Date();
   let list = {};
   list.FullYear = time.getFullYear()
   list.Month = time.getMonth()+1;
   list.Date = time.getDate();
   list.Hours = time.getHours();
   list.Minutes = time.getMinutes();
   list.Seconds = time.getSeconds();
   list.Time = time.getTime();


   let listresponse = '{"Year":'+list.FullYear+',"Month":'+list.Month+',"Date":'+list.Date+',"Hours":'+list.Hours+',"Minutes":'+list.Minutes+',"Seconds":'+list.Seconds+',"Time":'+list.Time+'}';

   response.write(listresponse);
   response.end();
}).listen(2415);

// 控制台会输出以下信息
console.log('Server running at http://127.0.0.1:2415/');