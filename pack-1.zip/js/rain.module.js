(function(){
    console.log(query('div'));
})