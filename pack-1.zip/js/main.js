
query('body')[0].scroll(() => {console.log(scrollRsate(query('body')[0]));})

// hitokoto api
query('.hitokoto')[0].click(() => {
    let ahitokoto = query('.hitokoto')[0].innerHTML;
    if (hitokotoDone) {
        hitokotoDone = false;
        console.log(query('.hitokoto')[0]);
        for (let count = 0; count != ahitokoto.length + 1; count++) {
            setTimeout(() => {
                query('.hitokoto')[0].innerHTML = ahitokoto.substr(0, ahitokoto.length - count);
                if (count == ahitokoto.length) {
                    query('.hitokoto')[0].innerHTML = '&nbsp';
                    console.log('Done!');
                    setTimeout(() => {
                        return hitokoto();
                    }, 100)
                }
            }, 100 * count);

        }
    }
});
var hitokotoDone;
function hitokoto() {
    var Thitokoto = new XMLHttpRequest();
    Thitokoto.open('GET', 'https://v1.hitokoto.cn/?encode=json&max_length=' + parseInt(document.body.clientWidth / 30));
    console.log(parseInt(document.body.clientWidth / 30));
    Thitokoto.send();
    Thitokoto.onreadystatechange = function () {
        if (Thitokoto.readyState == 4 && Thitokoto.status == 200) {
            Thitokoto = JSON.parse(Thitokoto.response)['hitokoto'];
            for (let count = 0; count != Thitokoto.length + 1; count++) {
                setTimeout(() => {
                    // console.log(Thitokoto.substr(0, count));

                    if(Thitokoto.substr(count-1, count)!='，'){
                        // query('.hitokoto')[0].innerHTML += String.fromCharCode(parseInt(Thitokoto.substr(count-1, count).charCodeAt().toString(2),2));

                        list = ['!','"','#','$','%','&',"'",'*','+',',','-',"'",'.','/','0','1','2','3','4','5','6','7','8','9',':',';','<','=','>','?','@','A','B,','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z','\\','^','_','`','a','b','c','d','e','f','g','h','i',',','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z','~']

                        let random = parseInt(Math.random()*88);
                        console.log(list[random]+':'+random);
                        query('.hitokoto')[0].innerHTML += list[random];
                    }
                    setTimeout(()=>{
                        query('.hitokoto')[0].innerHTML = Thitokoto.substr(0, count);
                    },30 * count)
                    
                    if (count == Thitokoto.length) {
                        hitokotoDone = true;
                    }
                }, 20 * count);
            }
        }
    }
}
// document.body.style.opacity

// (function (element) {
//     if (element.length == 0) { } else {
//         let nodeNameList = ['BUTTON']
//         for (let count = 0; count != element.length; count++) {
//             for (let icount = 0; icount != nodeNameList.length; icount++) {

//                 switch (element[count].nodeName) {
//                     case nodeNameList[icount]:
//                         console.log(nodeNameList[icount]);
//                         break;
                    
//                 }
//             }
//         }
//         // nodeName
//     }
// }(query('.rain')))})

setTimeout(()=>{hitokoto();},50)