"use strict";

function scrollRsate(a) {
    if (a.nodeName == "BODY") {
        return [(document.documentElement.scrollTop / (a.scrollHeight - a.clientHeight) * 100), (document.documentElement.scrollLeft / (a.scrollWidth - a.clientLeft) * 100)];
    } else {
        return [(a.scrollTop / (a.scrollHeight - a.clientHeight) * 100), (a.scrollLeft / (a.scrollWidth - a.clientLeft) * 100)];
    }
};

// var ajaxSetting = {
//     "Request": () => {
//         return new XMLHttpRequest();
//     }, "Zip": false
// };
/* setup */
// ajaxSetting.Request();
// ajaxSetting.Zip = true;
// function ajax(data) {
//     var xmlhttp = ajaxSetting.Request();
//     xmlhttp.open("GET", data.url, false);
//     xmlhttp.send();
//     xmlhttp.onreadystatechange = function (func, response) {
//         // func = func.replaceAll(/&response/g, response);
//         return Function(func)();
//     }(data.success, xmlhttp.response);
// };



// function xhr(){
//     let a = new XMLHttpRequest();
//     a.open("get","http://127.0.0.1:5500/server.js");
//     a.send();
//     return a;
// }


function querycookie(a) {
    if (typeof (a) == "undefined" && typeof (a) != "object") {
        let b = document.cookie.replaceAll(/ /g, "").split(";");
        let r = {};
        for (let count = 0; count != b.length; count++) {
            let c = b[count].split("=");
            r[c[0]] = c[1];
        }
        return r;
    } else if (typeof (a) == "object") {
        let b = Object.keys(a);
        for (let count = 0; count < b.length; count++) {
            document.cookie = b[count] + "=" + a[b[count]];
        }
    } else {
        return undefined;
    }
}





function query(data) {
    let a;
    a = document.querySelectorAll(data);

    for (let count = 0; a.length != count; count++) {
        query.event(a[count]);
    }
    
    return a;
};


// query.obj = query.prototype.obj = () => {
//     console.log("Done!");
// }

// window.click = ()=>{}

query.event = query.prototype.event = (a)=>{
    /* JS */
    a.click = function (b) { a.addEventListener('click', b); };
    a.dblclick = function (b) { a.addEventListener('dblclick', b); };
    a.scroll = function (b) { if (a.nodeName == 'BODY') { window.addEventListener('scroll', b); } else { a.addEventListener('scroll', b); }; };
    /*a.interval = (b,c) =>{setInterval(b,c);} */
    a.ready = function (b) { if (a.nodeName == 'BODY') { window.addEventListener('load', b); } else { a.addEventListener("load", b); }; };
    a.load = function (b) { let r = ajaxSetting.Request(); r.open("GET", b, false); r.send(); r.onreadystatechange = function (t, e) { t.innerHTML = e; }(a, r.response); };
    /* CSS */
    a.hide = function () { a.style.display = 'none'; };
    a.show = function () { a.style.display = ''; };
}



console.log("\n %c RainDropJS dev  %c https://github.com/XDKDEX/RainDrops \n", "color: #fadfa3; background: #030307; padding:5px 0;", "background: #fadfa3; padding:5px 0;");


