(function(){
    var request = new XMLHttpRequest();
    request.open("GET","./data/index.json");
    request.send()
}

)()