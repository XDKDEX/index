var inputelement;
var ielement;
function start(){
    inputelement = document.querySelectorAll('input')[0];
    ielement = document.querySelectorAll('iframe')[0];
    ielement.src = inputelement.value;
}