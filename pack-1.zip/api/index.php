<?php
    function Split($data='array'){
        for ($count=0; $count < sizeof($data) ; $count++) { 
            // echo $data[$count];
            if ($data[$count] == '^'){
                $url = substr($_SERVER['QUERY_STRING'],0,$count);
                $callback = substr($_SERVER['QUERY_STRING'],$count+1+9,sizeof($data));
                return array('url'=>$url,'callback'=>$callback);
            }
        }
    }
    // ;
    print_r(json_encode(Split(str_split($_SERVER['QUERY_STRING']))));

?>