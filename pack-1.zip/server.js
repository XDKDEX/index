﻿const http = require('http');
const fs = require('fs');
const url = require('url');
const cheerio = require('./module/cheerio');
const { type } = require('os');
 

// 创建服务器
http.createServer( function (request, response) {  

   // var { headers } = request;
   
   // let b = headers['cookie'].split('; ');
   // let r = {};
   // for (let count = 0; count != b.length; count++) {
   //     let c = b[count].split("=");
   //     r[c[0]] = c[1];
   // }
   // console.log(r);









   // 解析请求，包括文件名
   var pathname = url.parse(request.url).pathname;
   
   // 输出请求的文件名
   console.log("Request for " + pathname + " received.");
   
   // 从文件系统中读取请求的文件内容
   if(pathname.substr(1) == '')
   {
      fs.readFile('./index.html', function (err,data) {
         dataProcessing(data.toString());
         response.write(data.toString());
         response.end();
      });
   }
   else
   {
   fs.readFile(pathname.substr(1), function (err,data) {
      dataProcessing(data.toString());
      response.write(data.toString());
      response.end();
   });}
}).listen(8080);

function dataProcessing($){
   // $ = cheerio.load($); 
   // replace(/<p>(.*?)<\/p>/g,"替换的内容")
   // console.log($(":contains('TEST')"));
   // console.log($("[theme=true]")[0]);
   // console.log($.replace(/(.*?)/g,"替换(.*?)内容"));
   return $;
}
{/*<iframe src='//player.bilibili.com/player.html?bvid=BV1ns411D7NJ&cid=3524253&page=1&share_source=copy_web' scrolling='no' border='0' frameborder='no' framespacing='0' allowfullscreen='true'></iframe>*/}

function WriteResponse(data) {
   
}


console.log('Server running at http://127.0.0.1:8080/');