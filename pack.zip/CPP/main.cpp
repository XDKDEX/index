#if defined(__cplusplus)
extern "C" {
#endif
#include <SDL.h>
#if defined(__cplusplus)
};
#endif

// #include <windows.h>
// #include <time.h>
// #include <pthread.h>
// #include <stdio.h>
// #include <string.h>
// #include <SDL.h>


// #include <sys/types.h>
// #include <sys/stat.h>



// #include "./include/file.h"

// using namespace std;
// #define THREADS_NUMBER 1

// void *FixedUpdate(void *args);

int main()
{

    bool quit = false;
    SDL_Event event;

    SDL_Init(SDL_INIT_VIDEO);

    SDL_Window *screen = SDL_CreateWindow(
        "Name",
        SDL_WINDOWPOS_UNDEFINED,
        SDL_WINDOWPOS_UNDEFINED,
        640, 480, 0);
    for (; !quit;){
        SDL_WaitEvent(&event);

        switch (event.type)
        {
        case SDL_QUIT:
            quit = true;
            break;
        
        default:
            break;
        }
    }
    
    SDL_Quit();
    
    return 0;

    // char filename[255];

    // printf_s("filename:");
    // scanf("%s",filename);


    // FILE *ffpp;

    // if (!(ffpp = fopen(filename,"r"))){
    //     printf_s("error!\n");
    //     return main();
    // }
    

    // struct stat statbuf;

    // stat(filename,&statbuf);


    // char temp[statbuf.st_size];
    // char txt[statbuf.st_size];

    // printf_s("%s",FileIO.read(ffpp,temp,txt));


    // fclose(ffpp);

    // getchar();
    // printf_s("\n");
    // return main();


    // return 0;


}

// void *FixedUpdate(void *args)
// {
//     int count = 0;
//     while (true){
//         printf_s("%d\n",count);
//         Sleep(1000);
//         count++;
//     }
//      return NULL;
// }