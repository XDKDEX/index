# C++ win32 GUI 笔记

`114514`

[ssdsd](114514 "222")

```cpp
#include <windows.h>
int main(){

}
```
