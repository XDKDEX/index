#include <windows.h>
#include <time.h>
#include <pthread.h>
#include <stdio.h>
#include <string.h>

void *FixedUpdate(void *args);

const char g_szClassName[] = "myWindowClass";

void *FixedUpdate(void *args)
{
    while (TRUE)
    {
        Sleep(1000);
        MessageBox(NULL, "Test", "Test", MB_OK | MB_ICONINFORMATION);
    }

    return NULL;
}

LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
    const char *strT = "Test text";
    PAINTSTRUCT ps;
    HDC hdc = BeginPaint(hwnd, &ps);
    switch (msg)
    {
    // case WM_LBUTTONDOWN:WM_RBUTTONDOWN
    case WM_LBUTTONDOWN:
    {
        pthread_create(NULL, NULL, FixedUpdate, NULL);

        char szFileName[MAX_PATH];
        HINSTANCE hInstance = GetModuleHandle(NULL);

        GetModuleFileName(hInstance, szFileName, MAX_PATH);
        MessageBox(hwnd, szFileName, "This program is(You clicked L button):", MB_OK | MB_ICONINFORMATION);
    }
    break;
    case WM_RBUTTONDOWN:
    {
        char szFileName[MAX_PATH];
        HINSTANCE hInstance = GetModuleHandle(NULL);

        GetModuleFileName(hInstance, szFileName, MAX_PATH);
        MessageBox(hwnd, szFileName, "This program is(You clicked R button):", MB_OK | MB_ICONINFORMATION);
    }
    break;
    case WM_CLOSE:
        // DestroyWindow(hwnd);
        if (MessageBox(hwnd, "Are you sure?", "Are you sure?", MB_OKCANCEL) == IDOK)
        {
            DestroyWindow(hwnd);
        }
        break;
    case WM_DESTROY:
        PostQuitMessage(0);
        break;
    case WM_PAINT:
        TextOut(hdc, 0, 0, strT, size_t(strT));
        EndPaint(hwnd, &ps);
        return 0;
        break;
    default:
        return DefWindowProc(hwnd, msg, wParam, lParam);
    }
    return 0;
}

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance,
                   LPSTR lpCmdLine, int nCmdShow)
{
    WNDCLASSEX wc;
    HWND hwnd;
    MSG Msg;

    wc.cbSize = sizeof(WNDCLASSEX);
    wc.style = 0;
    wc.lpfnWndProc = WndProc;
    wc.cbClsExtra = 0;
    wc.cbWndExtra = 0;
    wc.hInstance = hInstance;
    wc.hIcon = LoadIcon(NULL, IDI_APPLICATION);
    wc.hCursor = LoadCursor(NULL, IDC_ARROW);
    wc.hbrBackground = (HBRUSH)(COLOR_WINDOW);
    wc.lpszMenuName = NULL;
    wc.lpszClassName = g_szClassName;
    wc.hIconSm = LoadIcon(NULL, IDI_APPLICATION);

    // AllocConsole();
    // printf("Test");

    hwnd = CreateWindowEx(
        WS_EX_CLIENTEDGE,
        g_szClassName,
        "Title",
        WS_OVERLAPPEDWINDOW,
        CW_USEDEFAULT, CW_USEDEFAULT, 360, 360,
        NULL, NULL, hInstance, NULL);

    if (hwnd == NULL)
    {
        MessageBox(NULL, "Window Creation Failed!", "Error!",
                   MB_ICONEXCLAMATION | MB_OK);
        return 0;
    }

    ShowWindow(hwnd, nCmdShow);
    UpdateWindow(hwnd);

    while (GetMessage(&Msg, NULL, 0, 0) > 0)
    {
        TranslateMessage(&Msg);
        DispatchMessage(&Msg);
    }
    return Msg.wParam;
}