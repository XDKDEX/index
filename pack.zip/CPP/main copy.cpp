#include <windows.h>
#include <time.h>
#include <pthread.h>
#include <stdio.h>
#include <string.h>
#include <SDL.h>


#include <sys/types.h>
#include <sys/stat.h>



#include "./include/file.h"

using namespace std;
#define THREADS_NUMBER 1

void *FixedUpdate(void *args);

int main()
{

    // printf_s("Hello, World! \n");
    // pthread_t tids[THREADS_NUMBER];
    // for (int count = 0; count != THREADS_NUMBER; count++)
    // {
    //    pthread_create(&tids[count], NULL, FixedUpdate, NULL);
    // }

    // int fpint;

    // char filename[255];

    // scanf("%s",filename);

    char filename[255];

    printf_s("filename:");
    scanf("%s",filename);


    FILE *ffpp;

    if (!(ffpp = fopen(filename,"r"))){
        printf_s("error!\n");
        return main();
    }
    

    struct stat statbuf;

    stat(filename,&statbuf);


    char temp[statbuf.st_size];
    char txt[statbuf.st_size];

    printf_s("%s",FileIO.read(ffpp,temp,txt));


    fclose(ffpp);

    getchar();
    printf_s("\n");
    return main();
}

void *FixedUpdate(void *args)
{
    int count = 0;
    while (true){
        printf_s("%d\n",count);
        Sleep(1000);
        count++;
    }
     return NULL;
}