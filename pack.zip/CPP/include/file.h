#include <stdio.h>




struct FileIO {
    char* read(FILE * _file,char * _fileBuffer,char * txt){
        int g_count = 0;
        while (fgets(_fileBuffer,sizeof(_fileBuffer),_file)){
            for (int i_count = 0; _fileBuffer[i_count]!='\0'; i_count++){
                txt[g_count] = _fileBuffer[i_count];
                g_count++;
            }
        }
        txt[g_count--] = '\0';
        return txt;
    };
    int write(FILE * _file,char * _fileBuffer){
        if(fputs(_fileBuffer, _file))
            return true;
        return false;
    }
};
struct FileIO FileIO;


// char* fileread(FILE * _file,char* _fileBuffer,char* txt){

//     int g_count = 0;
//     while (fgets(_fileBuffer,sizeof(_fileBuffer),_file)){
//         for (int i_count = 0; _fileBuffer[i_count]!='\0'; i_count++){
//             txt[g_count] = _fileBuffer[i_count];
//             g_count++;
//         }
//     }
//     txt[g_count--] = '\0';
//     return txt;
// }



char* readline(FILE * _File,int __n,char* __filetemp){
    for (__n != 0;__n--;){
        fgets(__filetemp,sizeof(__filetemp),_File);
    }    
    return __filetemp;
}
