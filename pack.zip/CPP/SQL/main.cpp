#include <windows.h>
#include <time.h>
#include <stdio.h>
#include <string.h>

int main(){
    char aaa[255];

    scanf("%s", aaa);

    if (strstr(aaa,"CREATE")==0 && strstr(aaa,"DATABASE")==0){
        printf("::aaaa\n");
    }

    return main();
}